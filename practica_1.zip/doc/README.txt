Adrian Arribas Mateo 795593 y Ernesto Bielsa Gracia 798799
Práctica 1: Construcción de un analizador léxico para "adac"