Adrian Arribas Mateo 795593 y Ernesto Bielsa Gracia 798799
Pr�ctica 1: Construcci�n de un analizador l�xico para "adac".

Practica 2: Construccion de un analizador sintactico descendente para "adac" con
	recuperacion de errores en modo panico, saltando tokens hasta llegar a
	uno de los siguientes de sincronizacion segun el caso: ';', 'end', ')', ']'.